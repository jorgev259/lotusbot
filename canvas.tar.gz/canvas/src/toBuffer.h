#include <cairo.h>


cairo_status_t toBuffer(void* c, const uint8_t* data, unsigned len);
